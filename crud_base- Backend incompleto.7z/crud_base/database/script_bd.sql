
-- Copiando estrutura do banco de dados para db
CREATE DATABASE IF NOT EXISTS `feira` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `feira`;

-- Copiando estrutura para bd
CREATE TABLE IF NOT EXISTS `produto` (
  `id` int NOT NULL AUTO_INCREMENT,
  `preco` DOUBLE NOT NULL,
  `nomeProd` varchar(100) COLLATE utf8mb4_bin NOT NULL DEFAULT '0',
  `fornecedor` varchar(100) COLLATE utf8mb4_bin NOT NULL DEFAULT '0',
  `descricao` varchar(100) COLLATE utf8mb4_bin NOT NULL DEFAULT '0',
  `categoria` varchar(200) COLLATE utf8mb4_bin NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

-- Copiando dados para a tabela feira.produto: ~6 rows (aproximadamente)
INSERT INTO `produto` (`id`, `preco`, `nomeProd`, `fornecedor`, `descricao`, `categoria`) VALUES
	(1, '12', 'Salame', 'Vilsom', 'Salame colonial', 'Colonial'),
	(2, '5', 'Uva', 'Lucas', 'Uvinha', 'Fruta'),
	(3, '7', 'Queijo', 'Zé', 'Queijinho', 'Colonial'),
	(5, '2', 'Tangerina', 'Pedro', 'Bergamota', 'Fruta'),
	(6, '3', 'Tomate', 'Magon', 'Tomatinho', 'Fruta');
