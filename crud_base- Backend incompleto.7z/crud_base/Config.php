<?php

class Config {

    const BD_HOST = "localhost";
    const BD_NOME = "feira";
    const BD_PORT = 3306;
    const BD_USUARIO = "root";
    const BD_SENHA = "";
    const BD_CHARSET = "utf8";

    const DIR_PROJETO = "/crud_base";
    const URL_PROJETO = "http://localhost";
}