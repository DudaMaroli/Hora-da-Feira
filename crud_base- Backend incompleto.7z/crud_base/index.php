<?php
include "./pagina/head.php";
?>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width">
  <title>Página Inicial</title>
  <link href="assets/css/style.css" rel="stylesheet" type="text/css" />
  <script src="assets/js/main.js"></script>
</head>

<section id="hero">
    <div class="hero-container">
      <div id="heroCarousel" data-bs-interval="2600" class="carousel slide carousel-fade" data-bs-ride="carousel">

        <div class="carousel-inner" role="listbox">

          <!-- Slide 1 -->
          <div class="carousel-item active" style="background-image: url(assets/img/slide/slide-2.jpg);">
            <div class="carousel-container">
              <div class="carousel-content">
                <h2 class="animate__animated animate__fadeInDown">Hora da Feira</h2>
                <p class="animate__animated animate__fadeInUp">Os produtos cultivados no campo!</p>
                  <div>
                    <a href="./pagina/tiposProd.php"
                      class="btn-get-started animate__animated animate__fadeInUp scrollto">Entrar</a> <br> 
                  </div>
                </div>
              </div><br><br>
                </div>
              </div>
            </div>
          </div>

          <!-- Slide 2 -->
          <div class="carousel-item" style="background-image: url(assets/img/slide/slide-1.jpg);">
            <div class="carousel-container">
              <div class="carousel-content">
                <h2 class="animate__animated animate__fadeInDown">Hora da Feira</h2>
                <p class="animate__animated animate__fadeInUp">Os produtos cultivados no campo!</p>
                  <div>
                    <a href="./pagina/tiposProd.php"
                      class="btn-get-started animate__animated animate__fadeInUp scrollto">Entrar</a><br>
                  </div>
                </div>
              </div><br><br>
                </div>
              </div>
            </div>
          </div>

          <!-- Slide 3 -->
          <div class="carousel-item" style="background-image: url(assets/img/slide/slide-4.jpg);">
            <div class="carousel-container">
              <div class="carousel-content">
                <h2 class="animate__animated animate__fadeInDown">Hora da Feira</h2>
                <p class="animate__animated animate__fadeInUp">Os produtos cultivados no campo!</p>
                  <div>
                  <a href="./pagina/tiposProd.php"
                      class="btn-get-started animate__animated animate__fadeInUp scrollto">Entrar</a>
                      <br>
                  </div>
                </div>
              </div><br><br>
                </div>
              </div>
            </div>
          </div>

        </div>

      </div>
    </div>
  </section>

<?php
include "./pagina/footer.php";
?>