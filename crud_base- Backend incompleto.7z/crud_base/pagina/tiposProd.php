<?php
include "../database/bd.php";
include "./head.php";
?>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width">
  <title>Página Inicial</title>
  <link href="assets/css/style.css" rel="stylesheet" type="text/css" />
  <script src="assets/js/main.js"></script>
</head>

<!DOCTYPE html>
<html>

<head>
  <title>Pagina Inicial</title>
  <script src="https://kit.fontawesome.com/ac3ebf4168.js" crossorigin="anonymous"></script>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2? family= Roboto:wght@100 & display=swap" rel="stylesheet">
  <!--importando fontes do google fontes-->
  <link href="style.css" rel="stylesheet" />
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!--tag para site responsivo-->
  <meta name="description" content="Feirinha">
  <!--para o google encontrar o site-->
  <meta name="keywords" content="feira, feirinha, colonial">
  <meta charset="utf-8" />

  
</head>

<body>

  <div id="columns">
    <div id="opcao">
      <figure>
        <a href="./produtoForm.php/">
          <img src="https://delage.com.br/wp-content/uploads/2021/04/armazem2-scaled.jpg">
          <figcaption>Cadastrar itens</figcaption>
        </a>
      </figure>
    </div>
    <div id="opcao">
      <figure>
        <a href="./produtoList.php/">
          <img src="https://i0.wp.com/gcene.com/wp-content/uploads/2019/02/frutas.jpg?fit=1200%2C628&ssl=1">
          <figcaption>Lista de itens</figcaption>
        </a>
      </figure>
    </div>
  </div>


</body>

</html>
<?php
include "./footer.php";
?>