<?php
include "../database/bd.php";
include "./head.php";

$objBD = new BD();
$objBD->conn();
$tb_nome = "produto";

if (!empty($_GET['id'])) {
    $result = $objBD->buscar($tb_nome, $_GET['id']);
    //select * from produto where id = ?
}
if (!empty($_POST)) {

    if (empty($_POST['id'])) {
        $objBD->inserir($tb_nome, $_POST);
    } else {
        $objBD->update($tb_nome, $_POST);
    }
    header("Location: ./produtoList.php");
}
?>

<h2>Formulário Produto</h2>
<form action="./produtoForm.php" method="post">
    <div class="row">
        <input type="hidden" name="id" value="<?php echo !empty($result->id) ? $result->id : "" ?>" /><br>
        <div class="col-4">
            <label>Preço</label>
            <input type="number" step="any" min="0.0" name="preco" class="form-control" value="<?php echo !empty($result->preco) ? $result->preco : "" ?>" /><br>
        </div>
        <div class="col-3">
            <label>Nome Produto</label>
            <input type="text" name="nomeProd" class="form-control" value="<?php echo !empty($result->nomeProd) ? $result->nomeProd : "" ?>" /><br>
        </div>
        <div class="col-3">
            <label>Fornecedor</label>
            <input type="text" name="fornecedor" class="form-control" value="<?php echo !empty($result->fornecedor) ? $result->fornecedor : "" ?>" /><br>
        </div>
        <div class="col-3">
            <label>Descrição</label>
            <input type="text" name="descricao" class="form-control" value="<?php echo !empty($result->descricao) ? $result->descricao : "" ?>" /><br>
        </div>
        <div class="col-3">
            <label>Categoria</label>
            <select name="categoria" id="categoria">
            <option value="option"selected >--- Selecione uma categoria ---</option>
            <option value="bebidas">Bebidas</option>
            <option value="temperos">Temperos</option>
            <option value="doces">Doces</option>
            <option value="frutasEVerduras">Frutas e Verduras</option>
            <option value="panificadora">Massas, Pães e Bolachas</option>
            <option value="outros">Outros</option>
        </select>
            
        </div>
        
    </div>
    <input type="submit" class="btn btn-success" value="Salvar" />
    <a href="/crud_base/pagina/produtoList.php" class="btn btn-primary">Voltar</a> <br>
</form>
<?php
include "./footer.php";
?>